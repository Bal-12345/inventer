/*import React, { useState } from 'react'
import { connect } from 'react-redux'
          
          import { incAction1,decAction1,incAction2,decAction2,resAction1, resAction2,incActionn} from './actions'
 const App = ({p1,p2,incAction1,decAction1,incAction2,decAction2,resAction1,resAction2,incActionn}) => {
   const[x,setX] =useState('')
  

  return (
    <div>
          <h1>{p1.score} & {p1.name}</h1>
          <button onClick={()=>incAction1(4)}>+</button>

          <button onClick={decAction1}>-</button>
          <button onClick={resAction1}>R</button>
            <div>
           <input
           type='text'
           value={x}
           onChange={(e)=>setX(e.target.value)}
           />
          <button onClick={()=>incActionn(Number(x)||0)}>Add</button>

          </div>

              <hr/>
          <h1>{p2.score} & {p2.name}</h1>
          <button onClick={()=>incAction2(10)}>+</button>
          <button onClick={decAction2}>-</button>
          <button onClick={resAction2}>R2</button>
          
       
    </div>
  )
}
const mapStateToProps = (state) => ({
   p1: state.r1,
   p2: state.r2


})

export default connect(mapStateToProps,{incAction1,decAction1,incAction2,decAction2,resAction1,resAction2,incActionn})(App)*/




         /*import React from 'react'
         import { useSelector,useDispatch } from 'react-redux'
         import { increment1,decrement1,selectUser1 } from './Reducer1'
         import { increment2,decrement2,selectUser2 } from './Reducer2'

         
         const App = () => {
          const e1=useSelector(selectUser1)
          const e2=useSelector(selectUser2)
           const dispatch =useDispatch()
          
          const incre1=()=>{
            dispatch(increment1(15))
           }
  
           const decre1=()=>{
            dispatch(decrement1())
           }
           const incre2=()=>{
            dispatch(increment2(10))
           }
           const decre2=()=>{
            dispatch(decrement2())
           }
           return (
              <center>
             <div>
                <h2>Profile-1</h2>
                 <p>{e1.name}</p>
                 <p>{e1.score}</p>
                 <button onClick={incre1}>+</button>
                 <button onClick={decre1}>-</button>

                <h2>Profile-2</h2>
                <p>{e2.name}</p>
                 <p>{e2.score}</p>
                 <button onClick={incre2}>+</button>
                 <button onClick={decre2}>-</button>


             </div>
             </center>
           )
         }
         
         export default App*/



/*import React from 'react'
import { useState } from 'react'
 
 const App = () => {
  const[x,setX]=useState([])
  const[y,setY]=useState([])
    

   const A= async()=>{
    let p =await fetch('https://fakestoreapi.com/products')
    let q=await p.json()
     return q

   }

   const B= async()=>{
    let p1 =await fetch('https://jsonplaceholder.typicode.com/posts')
    let q1=await p1.json()
    return q1
  

   }

   const All= async()=>{

    const[x1,y1]= await Promise.all([A(),B()])
     
     setX(x1)
     setY(y1)
   }
     All();

   return (
     <div>
        {x.map((i,index)=><li key={index}>{i.title}</li>)}

             <hr/>
          {y.map((j,index)=><li key={index}>{j.title}</li>)}


     </div>
   )
 }
 
 export default App*/



/*import React,{useEffect, useState,} from 'react'

      
      const App = () => {
          const[x,setX]  =  useState([])
        
        useEffect(() => {
          fetch('https://dummyjson.com/products')
          .then(
            res => res.json()
          ).then(
            json=>setX(json.products)
          )
          
    
          

        })
       
        
         
        return (
          <div>
              {x.map((i,index)=><li key={index}>{i.title}</li>)}
              


          </div>
        )
      }
      
      export default App*/


     /*import React, { useEffect, useState } from 'react';
        const App = () => {
          const [products, setProducts] = useState([]);
        
          useEffect(() => {
            // Fetch data from the API and update the state
            fetch('https://dummyjson.com/products')
              .then((res) => res.json())
              .then((data) => setProducts(data));
          }, []); // The empty dependency array ensures that the effect runs only once on component mount
        
          return (
            <div>
              <h1>Product List</h1>
              <ul>
                {products.map((product) => (
                  <li key={product.id}>{product.name}</li>
                ))}
              </ul>
            </div>
          );
        };
        
        export default App;*/



      /*import React, { useEffect, useState } from 'react';
          const App = () => {
          const [products, setProducts] = useState([]);
          const [loading, setLoading] = useState(true);
          const [error, setError] = useState(null);
        
          useEffect(() => {
            fetch('https://dummyjson.com/products')
              .then((res) => res.json())
              .then(
                (data) => {
                  setProducts(data);
                  setLoading(false); // Data has been loaded successfully
                },
                (err) => {
                  setError(err); // Handle any errors that occur during the fetch
                  setLoading(false);
                }
              );
          }, []);
        
          if (loading) {
            return <div>Loading...</div>;
          }
        
          if (error) {
            return <div>Error: {error.message}</div>;
          }
        
          return (
            <div>
              <h1>Product List</h1>
              <ul>
                {products.map((product) => (
                  <li key={product.id}>{product.name}</li>
                ))}
              </ul>
            </div>
          );
        };
        
        export default App;*/


        /*import React,{useEffect,useState} from 'react'

       const A=async()=>{
        const p= await fetch('https://api.steinhq.com/v1/storages/5e732accb88d3d04ae0815ae/StateWiseHealthCapacity')
        const data= p.json()
        return data

       }


       const B=async()=>{
        const q= await fetch('https://jsonplaceholder.typicode.com/posts')
        const data= q.json()
        return data

       }


       const C=async()=>{
        const r= await fetch('https://api.covidtracking.com/v1/states/ca/daily.json')

        const data= r.json()
        return data

       }

      const App = () => {
       const [x,setX] = useState([])
       const [y,setY] = useState([])
       const [z,setZ] = useState([])


        useEffect(()=>{
          async function All(){
            const[x1,y1,z1] = await Promise.all([A(),B(),C()])
             setX(x1)
             setY(y1)
             setZ(z1)
            }
            All()

        },[])
         return (
          <div>
            { x.map((i,index)=><li key={index}>{i.State}</li>)}
                       <hr/>
            { y.map((j,index)=><li key={index}>{j.title}</li>)}
                       <hr/>
            { z.map((k,index)=><li key={index}>{k.date}</li>)}


          </div>
        )
      }
      
      export default App*/


           /*import React from 'react'
             import { useState } from 'react'
             
             const App = () => {
                 const[x,setX] = useState('')
                 const[y,setY] = useState([])
                  console.log(y)
                const fun=() => {
                   if(x===''){
                    alert('Please fill it')
                   }else{
                      let z=y.find(t=>t===x)
                       if(z!==undefined){
                        alert('already is a string')
                       }else{
                       setY([...y,x])
                   }
                  }
                }
          
               return (
                 <div>
                    <h1>To do list</h1>
                   <div>
                     <input type='text' onChange={(e)=>setX(e.target.value)}/>
                     <input type='button' value='Add' onClick={fun}/>

                   </div>
                   {
                     y.map((i,index)=><li k={index}>{i}</li>)

                   }

                 </div>
               )
             }
             
             export default App*/




/*import React, { useState, useEffect } from 'react';

const App = () => {
  const [userData, setUserData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://jsonplaceholder.typicode.com/users');
        const data = await response.json();
        setUserData(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleLogout = () => {
    // Implement your logout logic here
    console.log('Logout clicked');
  };

  return (
    <div>
      <h2>User Data List</h2>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <ul>
          {userData.map((user) => (
            <li key={user.id}>
              <strong>Name:</strong> {user.name}, <strong>Address:</strong> {user.address.city}, {user.address.street}
            </li>
          ))}
        </ul>
      )}
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default App;*/



/*import React, { useState, useEffect } from 'react';

const App = () => {
  const [userData, setUserData] = useState(null);
  const [isLoggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch('https://jsonplaceholder.typicode.com/users');
        const data = await response.json();
        // Assuming the API returns an array of users
        setUserData(data[0]);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, []);

  const handleLogin = () => {
    setLoggedIn(true);
  };

  const handleLogout = () => {
    setLoggedIn(false);
  };

  return (
    <div>
      {userData ? (
        <div>
          <h2>User Information</h2>
          <p>
            <strong>Name:</strong> {userData.name}
          </p>
          <p>
            <strong>Email:</strong> {userData.email}
          </p>
          {isLoggedIn ? (
            <button onClick={handleLogout}>Logout</button>
          ) : (
            <button onClick={handleLogin}>Login</button>
          )}
        </div>
      ) : (
        <p>Loading user data...</p>
      )}
    </div>
  );
};

export default App;*/



/*import React, { useState } from 'react';

const Home = () => <div>Home Page</div>;
const About = () => <div>About Page</div>;
const Contact = () => <div>Contact Page</div>;

const App = () => {
  const [currentPage, setCurrentPage] = useState('home');

  const handleNavigation = (page) => {
    setCurrentPage(page);
  };

  return (
    <div>
      <nav>
        <button onClick={() => handleNavigation('home')}>Home</button>
        <button onClick={() => handleNavigation('about')}>About</button>
        <button onClick={() => handleNavigation('contact')}>Contact</button>
      </nav>

      <div>
        {currentPage === 'home' && <Home />}
        {currentPage === 'about' && <About />}
        {currentPage === 'contact' && <Contact />}
      </div>
    </div>
  );
};

export default App*/


/*import React, { forwardRef, useImperativeHandle, useState ,useRef} from 'react';

  const ChildComponent = forwardRef((props, ref) => {
    const [count, setCount] = useState(0);
  
    // Function to increment count
    const incrementCount = () => {
      setCount(count + 1);
    };
  
    // Expose the incrementCount function to the parent component
    useImperativeHandle(ref, () => ({
      increment: incrementCount,
    }));
  
    return (
      <div>
        <h2>Child Component</h2>
        <p>Count: {count}</p>
      </div>
    );
  });
  
  //export default ChildComponent;


 // import React, { useRef } from 'react';
  //import ChildComponent from './ChildComponent';
  
  const ParentComponent = () => {
    // Create a ref to hold the child component instance
    const childRef = useRef();
  
    // Function to call the child component's increment function
    const handleIncrement = () => {
      if (childRef.current) {
        childRef.current.increment();
      }
    };
  
    return (
      <div>
        <h1>Parent Component</h1>
        <button onClick={handleIncrement}>Increment Child Count</button>
        <ChildComponent ref={childRef} />
      </div>
    );
  };
  
  export default ParentComponent;*/
  
  

/*import React, { useState, useEffect } from 'react';

const ApiDataFilter = () => {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // Fetch data from the API
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch('https://dummyjson.com/users/1');
      const result = await response.json();
      setData(result);
      setFilteredData(result); // Set filtered data initially to all data
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleSearch = () => {
    // Filter data based on the search term
    const filtered = data.filter(item =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredData(filtered);
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Search..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>

      <ul>
        {filteredData.map(item => (
          <li key={item.id}>{item.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default ApiDataFilter;*/



/*import React, { useEffect } from 'react';
const withLogger = (WrappedComponent) => {
  return function WithLogger(props) {
    useEffect(() => {
     console.log(`Component ${WrappedComponent.name} mounted`);
      return () => {
        console.log(`Component ${WrappedComponent.name} will unmount`);
      };
    }, []); 

    
    return <WrappedComponent {...props} />;
  };
};

const MyComponent = () => {
  return <div>This is my component</div>;
};

const MyComponentWithLogger = withLogger(MyComponent);
const App = () => {
  return (
    <div>
      <MyComponentWithLogger />
    </div>
  );
};

export default App;*/



//ex hoc class
/*import React, { Component } from 'react';

const withAuthentication = (WrappedComponent) => {
  return class extends Component {
    constructor(props) {
      super(props);

      this.state = {
        isAuthenticated: true,
      };
    }

    componentDidMount() {
    
      const isAuthenticated = true;

      this.setState({ isAuthenticated });
    }

    render() {
      const { isAuthenticated } = this.state;

      if (isAuthenticated) {
      
        return <WrappedComponent {...this.props} />;
      } else {
      
        return <p>You need to be authenticated to access this component.</p>;
      }
    }
  };
};

const SomeComponent = (props) => {
  return <div>Authenticated Component</div>;
};

export default withAuthentication(SomeComponent)*/

/*import React,{useState} from 'react'

   const HOC=(WrappedComponent)=>{
    function HOC(){
      const[x,setX] = useState(0)
      const inc=()=>{
       setX(x+1)
         }
         return <WrappedComponent inc={inc} x={x}/>
       }
    return HOC

    }
    
    
       const App = () => {
        return (
          <div>
           <A/>
           <B/>
         </div>
        )
      }
      export default App



   const A = HOC(({inc,x}) => {
   
    return (
      <div>
            <h1>componentA-{x}</h1>
            <button onClick={inc}>+</button> 

      </div>
    )
  })
  

    
  



  const B = HOC(({inc,x}) => {
  
   return (
     <div>
           <h1>componentB-{x}</h1>
           <button onClick={inc}>+</button> 

     </div>
   )
 })*/




 /*import React from 'react';

 const Button = ({ label, onClick }) => {
   return (
     <button onClick={onClick}>
       {label}
     </button>
   );
 };


const ParentComponent = () => {
  const handleButtonClick = () => {
    console.log('Button clicked!');
  
  };

  return (
    <div>
      <h1>Parent Component</h1>
      <Button label="Click me" onClick={handleButtonClick}s/>
    </div>
  );
};

export default ParentComponent;*/

  


/*import React from 'react'
import { useEffect } from 'react'

const App = () => {
 useEffect(()=>{
 fetch('https://dummyjson.com/docs/users').then(
  res=>res.json()
 ).then(
  json=>console.log(json)
 )

 })

  return (
    <div>App</div>
  )
}

export default App*/



/*import React, { useState } from 'react';
const ListSearch = () => {
  const [list, setList] = useState([1, 5, 5, 6, 6, 7, 7, 7]);
  const [searchValue, setSearchValue] = useState('');
  const [searchResult, setSearchResult] = useState(null);

  const handleSearch = () => {
    const valueToSearch = parseInt(searchValue, 10);
    if (!isNaN(valueToSearch)) {
      const result = list.includes(valueToSearch);
      setSearchResult(result ? `${valueToSearch} is in the list.` : `${valueToSearch} is not in the list.`);
    } else {
      setSearchResult('Please enter a valid number.');
    }
  };

  return (
    <div>
      <p>List items in 'a': {list.join(', ')}</p>
      <input
        type="text"
        placeholder="Enter a value to search"
        value={searchValue}
        onChange={(e) => setSearchValue(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>
      <p>{searchResult}</p>
    </div>
  );
};

export default ListSearch;*/






/*import React, { useState } from 'react';
const ListSearch = () => {
  const [x, setX] = useState([1, 5, 5, 6, 6, 7, 7, 7]);
  const [y, setY] = useState('');
  const [z, setZ] = useState(null);

  const handleSearch = () => {
    const valueToSearch = parseInt(y, 10);
    if (!isNaN(valueToSearch)) {
      const result = x.includes(valueToSearch);
      setZ(result ? `${valueToSearch} is in the list.` : `${valueToSearch} is not in the list.`);
      setY('')
      setX([])
    } else {
      setZ('Please enter a valid number.');
    }
  };

  return (
    <div>
      <p>List items in 'a': {x.join(', ')}</p>
      <input
        type="text"
        placeholder="Enter a value to search"
        value={y}
        onChange={(e) => setY(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>
      <p>{z}</p>
    </div>
  );
};

export default ListSearch;*/




            /*import React from 'react'
           import { useState } from 'react'
            
            const App= () => {
             const [ar,setAr]  = useState([1,2,3,4,5])
             const [sea,setSea]  = useState('')
             const [re,setRe] = useState(null)

             const handle=()=>{

             const p= parseInt(sea,10)
              if(!isNaN(p)){

                const q=ar.includes(p)
                setRe(q?`${sea} is inside`:`false`)


              }else{
                setRe('not inside')
              }

             }

              return (
                <div>
                  <p>{ar.join(',')}</p>
                  <input 
                  type='text'
                  value={sea}
                  placeholder='enter value to search'
                  onChange={(e)=>setSea(e.target.value)}
                 />
                 <button onClick={handle}>Search</button>
                 <p>{re}</p>

                </div>
              )
            }
            
            export default App*/





/*import React from "react";
 class App extends React.Component {
  constructor(props) {
    super(props);
    this.myInputRef = React.createRef();
  }

  componentDidMount() {
    // Accessing the DOM element
    this.myInputRef.current.focus();
  }

  render() {
    return <input ref={this.myInputRef} />;
  }
}
export default App*/



   /*import React from "react";
import { useRef } from "react";
 const App =() =>{
  const ref =useRef()

const fun=()=>{

    // Accessing the DOM element
  ref.current.focus();
  }


    return (
      <>
    <input ref={ref} />;
    <button onClick={fun}>Focus</button>
     </>
    )
}
export default App*/
  
  
  
  
/*import React, { forwardRef, useImperativeHandle,useRef, useState } from 'react';

const ChildComponent = forwardRef((props,ref) => {
  const [count, setCount] = useState(0);

  // Function to increment count
  const incrementCount = () => {
    setCount(count + 1);
  };

  // Expose the incrementCount function to the parent component
  useImperativeHandle(ref, () => ({
    increment: incrementCount,
  }));

  return (
    <div>
      <h2>Child Component</h2>
      <p>Count: {count}</p>
    </div>
  );
});






const App = () => {
  // Create a ref to hold the child component instance
  const childRef = useRef();

  // Function to call the child component's increment function
  const handleIncrement = () => {
    if (childRef.current) {
      childRef.current.increment();
    }
  };

  return (
    <div>
      <h1>Parent Component</h1>
      <button onClick={handleIncrement}>Increment Child Count</button>
      <ChildComponent ref={childRef} />
    </div>
  );
};

export default App*/




           /*import React,{forwardRef, useImperativeHandle, useRef, useState} from 'react'
           
           const Child = forwardRef((props,ref) => {
             const[count,setCount] = useState(0)
             const incrementCount=()=>{
                  setCount(count+1)

             }

             useImperativeHandle(ref,()=>({

                 inc:incrementCount


             }))


             return (
               <div>
                <h1>Child</h1>
                <h1>Count-{count}</h1>
               </div>
             )
           })
           
           

                const App = () => {

                 const ChildRef = useRef()

                  const incrementP=()=>{
                  if(ChildRef.current){
                    ChildRef.current.inc()

                  }
                 
              }

             return (
               <div>
                <h1>Parent</h1>
                <button onClick={incrementP}>click</button>
                <Child ref={ChildRef}/>

                </div>
             )
           }
           
           export default App*/





/*import React, { useState,useCallback } from 'react';

const ChildComponent = ({ onClick, label }) => {
  console.log(`Rendering ${label}`);
  return <button onClick={onClick}>{label}</button>;
};

const App = () => {
  const [count, setCount] = useState(0);

  const handleClick = useCallback(() => {
    console.log('Button clicked!');
    setCount(count + 1);
  },[count]);

  return (
    <div>
      <p>Count: {count}</p>
      <ChildComponent onClick={handleClick} label="Click me" />
    </div>
  );
};

export default App;*/



     // App.js

/*import React from 'react';
import { useQuery, gql } from '@apollo/client';

const GET_REPOSITORIES = gql`
  query {
    viewer {
      repositories(first: 5, orderBy: { field: CREATED_AT, direction: DESC }) {
        nodes {
          id
          name
          description
        }
      }
    }
  }
`;

const App = () => {
  const { loading, error, data } = useQuery(GET_REPOSITORIES);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const repositories = data.viewer.repositories.nodes;

  return (
    <div>
      <h1>My GitHub Repositories</h1>
      <ul>
        {repositories.map((repo) => (
          <li key={repo.id}>
            <h2>{repo.name}</h2>
            <p>{repo.description}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;*/








               /*import React from 'react'
               import { useState } from 'react'
             import { useReducer } from 'react'
              const initialstate=0
                    const  reducer=(state,action)=>{
                       
                        switch(action.type){
                        case 'INCREMENT':
                         return state+1
                         case 'DECREMENT':
                          return state-1
                          case 'INCREMENTN':
                          return state+action.payload
                          case 'RESET':
                            return initialstate
                             default:
                              return state
     

                      }

                    }

          const App = () => {
            const[nstate,dispatch] =useReducer(reducer,initialstate)
            const[x,setX] =useState('')

               return (
              <div>
                         <h1>{nstate}</h1>
                  <button onClick={()=>dispatch({type:'INCREMENT'})}>+</button>
                  <button onClick={()=>dispatch({type:'DECREMENT'})}>-</button>
                  <button onClick={()=>dispatch({type:'RESET'})}>R</button>
                
                  <div>
                    <input 
                    type='text'
                    value={x}
                    onChange={(e)=>setX(e.target.value)}
                    />
                  <button onClick={()=>dispatch({type:'INCREMENTN',payload:parseInt(x,10)||0})}>Add</button>

                   </div>
                 
              </div>
            )
          }
          
          export default App*/



         
          /*import React from 'react'
          import { useState } from 'react'
          
          const App = () => {
            const[x,setX] = useState('')
            const[y,setY] = useState([])

            console.log(y)
              const fun=()=>{
                if(x===''){
                  alert('Please enter text')
                }else{
                  let k=y.find((i)=>i===x)
                  if(k!==undefined){
                     alert('already selected')
                  }else{

                 setY([...y,x])
                  }
                }
              }

              return (
               <div>
                <input 
                type='text'
                value={x}
                onChange={(e)=>setX(e.target.value)}
                />
                <button onClick={fun}>Add</button>
               </div>
            )
          }
          
          export default App*/

      /*import React, { useState, useEffect } from 'react';
           const App = () => {
            const [items, setItems] = useState([]);
            const [cart, setCart] = useState([]);
          
            useEffect(() => {
              // Fetch data from the JSONPlaceholder API
              fetch('https://jsonplaceholder.typicode.com/posts')
                .then(response => response.json())
                .then(data => setItems(data))
                .catch(error => console.error('Error fetching data:', error));
            }, []);
          
            const addItemToCart = (item) => {
              // Add item to the cart
              setCart([...cart, item]);
            };
          
            return (
              <div>
                <h1>Posts</h1>
                <ul>
                  {items.map(item => (
                    <li key={item.id}>
                      {item.title}
                      <button onClick={() => addItemToCart(item)}>Add to Cart</button>
                    </li>
                  ))}
                </ul>
          
                <h2>Shopping Cart</h2>
                <ul>
                  {cart.map(cartItem => (
                    <li key={cartItem.id}>
                      {cartItem.title}
                    </li>
                  ))}
                </ul>
              </div>
            );
          };
          
          export default App;*/



 /*import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
            
            const App = () => {
              const[x,setX] =  useState([])
              const[cart,setCart] =  useState([])
              useEffect(()=>{
            
              fetch('https://fakestoreapi.com/products').then(
                res=>res.json()
              ).then(
                json => setX(json)
              )


              },[])

              const cartadd=(p)=>{
                  setCart([...cart,p])

              }
                 return (
                 <div>
                    <ul>
                       {x.map(p=>(
                       
                       <><li key={p.id}>
                           {p.title}
                         </li><button onClick={() => cartadd(p)}>add</button></>
                       ))}
                     </ul>
                      <hr/>
                      <ul>
                       {cart.map(q=>(
                       
                      <><li key={q.id}>
                         {q.title}
                       </li></>
                       ))}
                     </ul>

                </div>
              )
            }
            
            export default App*/








/*import React from 'react'
import {useState, useEffect } from 'react'
            
            const App = () => {
              const[x,setX] = useState([])
              const[cart,setCart] = useState([])

              useEffect(()=>{
                  fetch('https://dummyjson.com/products').then(
                    res=>res.json()

                  ).then(
                    json => setX(json.products)
                  )

              },[])
              const Aditem=(i)=>{
                setCart([...cart,i])


              }
              
              return (
                <div>
                  <ul>
                  {x.map(i =>(
                   <>
                   <li key={i.id}>{i.title}</li>
                   <button onClick={()=>Aditem(i)}>add</button></>
                   ))}
                  </ul>
                     
                    <ul>
                     {cart.map(j=>(
                      <li key={j.id}>{j.title}</li>
                      ))}

                  </ul>


                  </div>
              )
            }
            
            export default App*/




/*import React, { useState, useEffect } from 'react';

const App = () => {
  const [x, setX] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    fetch('https://dummyjson.com/products')
      .then((res) => res.json())
      .then((json) => setX(json.products));
  }, []);

  const addItem = (item) => {
    setCart([...cart, item]);
  };

  const removeItem = (id) => {
    console.log(id)
    //const updatedCart = cart.filter((item) => item.id !== id);
    //setCart(updatedCart);
  };

  return (
    <div>
      <ul>
        {x.map((item) => (
          <div key={item.id}>
            <li>{item.title}</li>
            <button onClick={(item) => addItem(item.id)}>Add</button>
          </div>
        ))}
      </ul>

      <ul>
        {cart.map((item) => (
          <div key={item.id}>
            <li>{item.title}</li>
            <button onClick={ removeItem}>Delete</button>
          </div>
        ))}
      </ul>
    </div>
  );
};

export default App;*/

          




    /*import React, { useState,useEffect } from 'react'
      const url='https://fakestoreapi.com/products'
      const App = () => {
        const[data,setData] = useState(null)
        const[token,setToken] = useState(null)
        const[error,setError] = useState(null)

        const login=()=>{
          let fToken='balu'
          localStorage.setItem('fToken',fToken)
          setToken(fToken)
         }


         const logout=()=>{
    
          localStorage.removeItem('fToken')
          setToken(null)
          setData(null)
          setError(null)
         }


         const dataFetch = async()=>{

           try{
            const response= await fetch(url,{
              headres:{
                Authorization:`bearer ${token}`
              }
            })
            const result= await response.json()
            setData(result)

           }catch(err){
             console.error(err)
           }

           }

           useEffect(() =>{
            const storedToken=localStorage.getItem('ftoken')

            if(storedToken){
               setToken(storedToken)


            }
          },[])


        return (
          <div>
               {token?(
                 <div>
                    <h1>Authenticated</h1>
                  <button onClick={dataFetch}>FetchD</button>
                  <button onClick={logout}>Logout</button>
                  {error &&<p>{error}</p>}
                  {data&&(
                    <>
                    {JSON.stringify(data,null,2)}
                    </>
                  )}
                  </div>
                  
               ):(
                 <>
                 <h1>Authentication required</h1>
                 <button onClick={login}>Login</button>
                 </>

               )


               }


          </div>
        )
      }
      
      export default App*/







 

/*import React,{useState} from 'react'
import  './styles.css'
const App = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
  });
  const [errors, setErrors] = useState({});
  return (
    <div>
      < Form/>

    </div>
  )
}

export default App





 function Form() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
  });
 
  const [errors, setErrors] = useState({});
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
 
  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validateForm(formData);
    if (Object.keys(validationErrors).length === 0) {
      // Form submission logic here
      console.log(formData);
    } else {
      setErrors(validationErrors);
    }
  };


  const validateForm = (data) => {
    let errors = {};
    if (!data.name) {
      errors.name = "Name is required";
    }
    if (!data.email.trim()) {
      errors.email = "Email is required";
    } else if (!isValidEmail(data.email)) {
      errors.email = "Invalid email format";
    }
    return errors;
  };


  const isValidEmail = (email) => {
    // Basic email validation
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };


  return (
    <div className="container">
      <h1>Contact Form</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
          />
          {errors.name && <span className="error">{errors.name}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
          {errors.email && <span className="error">{errors.email}</span>}
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
 }*/

 
 import React, { useState, useEffect } from 'react';


const App = () => {
  const [x, setX] = useState([]);
  const [y, setY] = useState('');

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(res => res.json()).then(
      
        json=>setX(json)
      )
      
  }, []);
  

  const handler = (e) => {
    setY(e.target.value);
  };

  const gun = () => {
    alert(`selected name: ${y}`);
  };

  return (
    <div>
      <label htmlFor='madhu'>Users</label><br />
      <select id='madhu' value={y} onChange={handler}>
        {x.map((i) => (
          <option key={i.id}>{i.name}</option>
        ))}
      </select>
      <button onClick={gun}>add</button>
      <p>selected name: {y}</p>
    </div>
  );
};

export default App;
